<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- write_head_public.twig -->
<title>
    Profiles - LibGuides at York House School
</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noarchive"/>

<!-- favicon.twig -->
<link rel="apple-touch-icon" sizes="180x180" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon-16x16.png">
<link rel="manifest" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/site.webmanifest">
<link rel="mask-icon" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#ffc40d">
<meta name="msapplication-config" content="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- !favicon.twig -->

<link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/jquery/css/jquery-ui.min.css?2691"/>
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/css3.14.3/lg-public-no-bs.min.css"/>
<script src="https://static-assets-ca.libguides.com/web/jquery/js/1.12.4_jquery.min.js"></script>
<!-- js_include_fallback_lg.twig -->
<script src="//code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script>jQuery.ui || document.write('<script src="https://static-assets-ca.libguides.com/web/jquery/js/jquery-ui.min.js?2691">\x3C/script>');</script>
<!-- !js_include_fallback_lg.twig -->
    <script type="text/javascript" src="https://static-assets-ca.libguides.com/web/js3.14.3/lg-public-no-bs.min.js"></script>
<!-- !write_head_public.twig -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

<!-- 
LibGuides Custom Bootstrap:
<link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/css3.14.3/lg-public.min.css">
-->
<style>
  /* BEGIN: Include dependencies from default LibGuide bundle */
  .hide {
    display: none;
  }
  #s-lg-az-index>.btn-group {
    flex-wrap: wrap;
  }
  
  .pagination {
      display: inline-block;
      padding-left: 0;
      margin: 20px 0;
      border-radius: 4px
  }

  .pagination>li {
      display: inline
  }

  .pagination>li>a,
  .pagination>li>span {
      position: relative;
      float: left;
      padding: 6px 12px;
      margin-left: -1px;
      line-height: 1.42857143;
      color: #337ab7;
      text-decoration: none;
      background-color: #fff;
      border: 1px solid #ddd
  }

  .pagination>li>a:hover,
  .pagination>li>span:hover,
  .pagination>li>a:focus,
  .pagination>li>span:focus {
      z-index: 2;
      color: #23527c;
      background-color: #eee;
      border-color: #ddd
  }

  .pagination>li:first-child>a,
  .pagination>li:first-child>span {
      margin-left: 0;
      border-top-left-radius: 4px;
      border-bottom-left-radius: 4px
  }

  .pagination>li:last-child>a,
  .pagination>li:last-child>span {
      border-top-right-radius: 4px;
      border-bottom-right-radius: 4px
  }

  .pagination>.active>a,
  .pagination>.active>span,
  .pagination>.active>a:hover,
  .pagination>.active>span:hover,
  .pagination>.active>a:focus,
  .pagination>.active>span:focus {
      z-index: 3;
      color: #fff;
      cursor: default;
      background-color: #337ab7;
      border-color: #337ab7
  }

  .pagination>.disabled>span,
  .pagination>.disabled>span:hover,
  .pagination>.disabled>span:focus,
  .pagination>.disabled>a,
  .pagination>.disabled>a:hover,
  .pagination>.disabled>a:focus {
      color: #777;
      cursor: not-allowed;
      background-color: #fff;
      border-color: #ddd
  }

  .pagination-lg>li>a,
  .pagination-lg>li>span {
      padding: 10px 16px;
      font-size: 18px;
      line-height: 1.3333333
  }

  .pagination-lg>li:first-child>a,
  .pagination-lg>li:first-child>span {
      border-top-left-radius: 6px;
      border-bottom-left-radius: 6px
  }

  .pagination-lg>li:last-child>a,
  .pagination-lg>li:last-child>span {
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px
  }

  .pagination-sm>li>a,
  .pagination-sm>li>span {
      padding: 5px 10px;
      font-size: 12px;
      line-height: 1.5
  }

  .pagination-sm>li:first-child>a,
  .pagination-sm>li:first-child>span {
      border-top-left-radius: 3px;
      border-bottom-left-radius: 3px
  }

  .pagination-sm>li:last-child>a,
  .pagination-sm>li:last-child>span {
      border-top-right-radius: 3px;
      border-bottom-right-radius: 3px
  }
  /* END: Include dependencies from default LibGuide bundle */

  select.form-control { /* Fix form select inputs */
    padding: .5rem .75rem 2rem .75rem
  }
  
  .navbar-collapse,
  body,
  .navbar-brand { /* Remove default LibGuides padding */
    padding: 0;
  }

  .navbar-brand {
    /* Place logo & text side by side */
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
  }

  .navbar-brand-logo {
    /* Scale Brand Logo */
    height: 3rem;
  }

  .navbar-brand-caption {
    /* Style Brand Text */
    text-wrap: wrap;
    font-size: .7rem;
    line-height: .7rem;
    font-weight: bold;
    text-transform: uppercase;
  }

  /* Hide default search bar */
  .pull-right>#s-lg-guide-header-search {
    display: none;
  }

  /* Any html inside an overhaul class is hidden by default. This lets us develop & test on the alternate guide without disturbing the development environment. */
  .overhaul {
    display: none !important;
  }

  /* CUSTOM TWEAKS*/
  /* Scale down profile image - Phillip's request */
  .s-lib-profile-image>img {
    width: 25%;
  }

  /* Remove tiny box title - Phillip's request */
  .s-lib-box-title {
    display: none;
  }

  /* Reformat google embeds to display properly. */
  .s-lg-widget>iframe {
    margin: auto !important;
    display: block !important;
  }
</style>
<script>
</script><script>
    var springStats = springStats || {};
    springStats.saConfig = springStats.saConfig || {
        site_id: 26075,
        tracking_parameters: {"_st_site_id":26075},
        tracking_server_host: "libguides-proc-ca.springyaws.com"
    };
</script>
<script  src="https://static-assets-ca.libguides.com/web/js/sa.min.js?3116"></script>
<script type="text/javascript">
            //====================================================
            springSpace.publicObj = new springSpace.public.Public({
                constant: {
                    PROCESSING: {},
                    CONTENT: {}
                }
            });
            //====================================================
            jQuery(document).ready(function() {
                if (0 == 0) {
                    loadProfileList(0);
                } else {
                    top.window.helptips = new springSpace.sui.helptip({placement: "right"});
                }
                springSpace.UI.xhrPopover();
            });
            //====================================================
            setActiveButton=function(id) {
                jQuery("#s-lg-profile-name-btn").removeClass("active");
                jQuery("#s-lg-profile-subject-btn").removeClass("active");
                jQuery(id).addClass("active");
            }
            //====================================================
            toggleSubjectBoxes=function(subject_id) {
                jQuery("#s-lg-profile-guides-div").html("");

                var is_subject = (subject_id != 0);
                if (is_subject) {
                    xhr = jQuery.ajax({
                        url: "prf_process.php",
                        data: {
                            action: 531,
                            subject_id: subject_id
                        },
                        type: "GET",
                        dataType: "json",
                        success: function(response, textStatus, jqXHR) {
                            if ( response.errCode == 200 ) {
                                jQuery("#s-lg-profile-guides-div").html(response.data.guides);
                            }
                            else {
                                springSpace.UI.error(response.errCode);
                            }
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            springSpace.UI.error(errorThrown);
                        }
                    });
                }

                jQuery("#s-lg-profile-az-div").toggle(!is_subject);
                jQuery("#s-lg-profile-help-div").toggle(!is_subject);
                jQuery("#s-lg-profile-guides-div").toggle(is_subject);
            }
            //====================================================
            loadProfileList=function(subject_id) {
                jQuery("#s-lg-profile-content").html('<div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div>');
                jQuery("#s-lg-profile-count").html(0);

                //set the active button
                setActiveButton(subject_id == 0 ? "#s-lg-profile-name-btn" : "#s-lg-profile-subject-btn");

                // toggle the right hand boxes based on if this is a subject or not
                toggleSubjectBoxes(subject_id);

                // hide the subject view if needed
                if (subject_id == 0) { toggleSubjectView(false); }

                // get the data
                xhr = jQuery.ajax({
                    url: "prf_process.php",
                    data: {
                        action: 530,
                        subject_id: subject_id
                    },
                    type: "GET",
                    dataType: "json",
                    success: function(response, textStatus, jqXHR) {
                        if ( response.errCode == 200 ) {
                            jQuery("#s-lg-profile-content").html(response.data.html);
                            jQuery("#s-lg-profile-count").html(response.data.count);
                        }
                        else {
                            springSpace.UI.error(response.errCode);
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        springSpace.UI.error(errorThrown);
                    }
                });
            }
            //====================================================
            handleSubjectBtnClick=function() {
                jQuery("#s-lg-profile-count").html(0);
                if (!jQuery("#s-lg-profile-subjects").is(":visible")) {
                    jQuery("#s-lg-profile-content").html("");
                }
                toggleSubjectView(true);
            }
            //====================================================
            toggleSubjectView=function(visible) {
                jQuery("#s-lg-profile-subjects").toggle(visible);
                if (visible) { setActiveButton("#s-lg-profile-subject-btn"); }
            }
            //====================================================
            filterBySubject=function(subject_id) {
                toggleSubjectView(true);
                loadProfileList(subject_id);
            }
            //====================================================
            jQuery(function() {
        jQuery(document).ready(function () {
            springSpace.springTrack.trackPage({_st_type_id: '20'});
        });
            });
        </script><style>
            .pad-left-sm { margin-left:10px; }
            .s-lib-featured-profile-container { width: 160px; margin:0 10px 20px 10px !important; }
            .s-lib-profile-container .s-lib-profile-name, .s-lib-profile-container .s-lib-profile-pronouns { display:none; }
            .s-lib-profile-image { margin-bottom:30px; }
            .s-lg-profile-personal-statement { padding:10px; background-color:#fafafa; border:1px solid #ccc; }
            </style></head>
<body class="s-lib-public-body">
<a id="s-lg-public-skiplink" class="alert-info" href="#s-lib-public-main">Skip to Main Content</a><!-- BEGIN: Page Header -->
<nav class="navbar navbar-expand-xl navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="/home">
            <img class="navbar-brand-logo"
                src="https://d1qywhc7l90rsa.cloudfront.net/accounts/165281/images/YHS-Rose-Lock-Up-Square-Full-Colour-RGB.png"
                alt="YHS Square Logo Lock-Up">
            <!-- Use CSS to wrap this text instead of hardcoded breaks if possible. -->
            <span class="navbar-brand-caption">Senior <br>Learning <br>Commons</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="/home">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Our Collection
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/az.php">All Resources</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/resources/catalogue" target="_blank">Our Catalogue</a></li>
                        <li><a class="dropdown-item" href="/orders">Request A Title</a></li>
                        <li><a class="dropdown-item" style="display: none;" href="#">Volunteer's Spotlight</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        How To..?
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/how-to">All "How To" Guides</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="/how-to/research-sources">Searching for Sources</a></li>
                        <li><a class="dropdown-item" href="/how-to/find-your-book">Find Your Next Book</a></li>
                        <li><a class="dropdown-item" href="/how-to/3d-printing">3D Printing</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        What Is..?
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/what-is">All "What Is" Guides</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/what-is/reading-lists">Reading Lists</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/what-is/truth-and-reconciliation">Truth & Reconcilliation</a></li>
                        <li><a class="dropdown-item" href="/what-is/mental-health">Mental Health</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Assignments
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/assignments">All Assignments</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/assignments/this-year">This Year</a></li>
                        <li><a class="dropdown-item" href="/assignments/2023-24">2023-24</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Student Initiatives
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/initiatives">All Initiatives</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/initiatives/publications">Student Publications</a></li>
                        <li><a class="dropdown-item" href="/initiatives/model-un">Model UN</a></li>
                        <li><a class="dropdown-item" style="display: none;" href="#">Tutoring</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/about">About</a>
                </li>
            </ul>
            <form class="d-flex" action="https://yorkhouse.libguides.com/srch.php" method="GET">
                <input class="form-control me-2" type="text" name="q" maxlength="260" placeholder="Search" aria-label="Search" role="search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav><!-- END: Page Header -->
<!-- BEGIN: Content Header -->
<div id="s-lib-public-header" class="s-lib-header container s-lib-side-borders">
    <nav id="s-lib-bc" aria-label="breadcrumb">
        <ol id="s-lib-bc-list" class="breadcrumb"><li id="s-lib-bc-customer" class="breadcrumb-item"><a href="https://www.yorkhouse.ca">York House School</a></li><li id="s-lib-bc-site" class="breadcrumb-item"><a href="https://yorkhouse.libguides.com/">LibGuides</a></li><li id="s-lib-bc-page" class="active breadcrumb-item">Profiles</li></ol>    </nav>
    <h1 id="s-lib-public-header-title">Profiles</h1>
    <div id="s-lib-public-header-desc">&nbsp;</div>
</div>
<!-- END: Content Header -->
<!-- BEGIN: Nav Bar -->
<div id="s-lib-public-nav" class="container s-lib-side-borders">
    </div>
<!-- END: Nav Bar -->
<!-- BEGIN: content -->
<div id="s-lib-public-main" class="s-lib-main container s-lib-side-borders" tabindex="-1">
    <!-- profile_navbar.html -->
<div class="clearfix">
    <div id="s-lg-profile-nav">
        <ul>
            <li>
                <ul class="nav nav-pills" style="margin-bottom:0;">
                    <li id="s-lg-profile-count-btn">
                        <span id="s-lg-profile-count" class="badge">0</span> PROFILES
                    </li>
                    <li id="s-lg-profile-name-btn" class="s-lg-index-nav-btn active">
                        <a href="#" onclick="loadProfileList(0);">
                            BY NAME
                        </a>
                    </li>
                    <li id="s-lg-profile-subject-btn" class="s-lg-index-nav-btn">
                        <a href="#" onclick="handleSubjectBtnClick();">
                            BY SUBJECT
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>
    <section aria-label="List of Profiles">
        <div id="s-lg-profile-cols" class="row">
            <div id="col1" class="col-md-8 center">
                <div id="s-lg-profile-subjects" style="display:none; margin-bottom:20px;" class="pad-right-sm">
                    <!-- profiles_by_subject.twig -->
<div class="col-md-10" style="display:inline-block;">
    <label for="sel-guide-drop" class="sr-only">Please select a subject...</label>
    <select name="sel-guide-drop" id="sel-guide-drop" class="form-control" style="width:100%">
        <option selected value="">Please select a subject...</option>
            </select>
</div>

<div class="col-md-2 pad-left-none" style="display:inline-block;">
    <button type="button" class="btn btn-primary btn-small" onclick="filterBySubject(jQuery('#sel-guide-drop').val());">
        Go
    </button>
</div>

<div style="clear:both;"></div>
<!-- !profiles_by_subject.twig -->
                </div>
                <div id="s-lg-profile-content">
                    <div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div>
                </div>
            </div>
            <div id="col2" class="col-md-4 center">
                <div id="s-lg-profile-search-div"><div class="margin-bottom-xlg"><div class="s-lib-public-side-header"><h2 class="pad-bottom-sm">Search</h2></div><div class="txt pad-top-sm"><div class="margin-bottom-med">Search the full text of this site. Results will link to pages containing your terms; results from subject page searches are automatically filtered by that subject.</div></div><div class="input-append"><form role="search" method="GET" action="/srch.php"><label class="control-label sr-only" for="s-lg-guide-search">Guide Search Terms</label><input class="form-control" name="q" id="s-lg-guide-search" type="text" placeholder="Enter Search Words" maxlength="260"><button class="btn btn-info" type="submit" style="margin-top:2px;" role="button">Search</button></form></div></div></div>                <div id="s-lg-profile-az-div"><div class="margin-bottom-xlg"><div class="s-lib-public-side-header"><h2 class="pad-bottom-sm">A-Z Database List</h2></div><div class="txt pad-top-sm">Full list of Databases the library subscribes to, including trial access.</div><a href="/az.php" class="btn btn-info s-lg-hp-btn-section" role="button">Go to A-Z List</a></div></div>                <div id="s-lg-profile-help-div"><div class="margin-bottom-xlg"><div class="s-lib-public-side-header"><h2 class="pad-bottom-sm">Help is Just a Click Away</h2></div><div class="txt pad-top-sm">Search our FAQ Knowledge base, book a research appointment, reserve a room, register for an event, ask a question, chat, send comments...</div><a href="https://www.google.com/" class="btn btn-info s-lg-hp-btn-section" role="button">LibAnswers & LibChat</a></div></div>                <div id="s-lg-profile-guides-div"><div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div></div>            </div>
        </div>
    </section>
</div>
<!-- END: content -->
<!-- BEGIN: Page Footer -->
<div id="s-lib-footer-public" class="s-lib-footer footer container s-lib-side-borders"><div><div id="s-lib-footer-brand">Powered by Springshare.</div><div id="s-lib-footer-rights">All rights reserved.</div><div id="s-lib-footer-login-link"><a href="https://yorkhouse.libapps.com/libapps/login.php?site_id=26075">Login to LibApps</a></div></div><div id="s-lib-footer-support-link"></div></div></div><!-- END: Page Footer -->
<div id="s-lib-alert" title=""><div id="s-lib-alert-content"></div></div><!-- popover.twig -->
<div id="s-lib-popover-title" class="hide">
    <span class="text-info">
        <strong>title</strong>
    </span>

    <button type="button" id="popclose" class="close" onclick="jQuery('.s-lib-popover').popover('hide')">
        &times;
    </button>
</div>

<div id="s-lib-popover-content" class="hide">
    <i class="fa fa-refresh fa-spin"></i> Loading...
    <button class="btn btn-default btn-sm popclose" type="button">Close</button>
</div>
<!-- !popover.twig -->
<!-- scroll_top.twig -->
<div id="s-lib-scroll-top">
    <a href="javascript:void(0);" onclick="jQuery('body').focus();" title="Back to Top"
       aria-label="Back to Top">
        <span class="fa-stack fa-lg" aria-hidden="true">
            <i class="fa fa-square-o fa-stack-2x"></i>
            <i class="fa fa-angle-double-up fa-stack-1x" style="position:relative; bottom:2px;"></i>
        </span>
    </a>
</div>
<!-- !scroll_top.twig -->

<!-- BEGIN: Custom Footer -->


<!-- END: Custom Footer -->
</body>
