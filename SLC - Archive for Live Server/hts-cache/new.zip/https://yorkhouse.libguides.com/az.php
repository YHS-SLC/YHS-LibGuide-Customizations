<!DOCTYPE html>
<html lang="en">
<head>
    <title>A-Z Databases</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <script>
        var is_bootstrap = 0;
    </script>

    <!-- Public head code template -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noarchive"/>

<!-- favicon.twig -->
<link rel="apple-touch-icon" sizes="180x180" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon-16x16.png">
<link rel="manifest" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/site.webmanifest">
<link rel="mask-icon" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#ffc40d">
<meta name="msapplication-config" content="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- !favicon.twig -->


<link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/jquery/css/jquery-ui.min.css?2691"/>

<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>

    <link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/css3.14.3/lg-public-no-bs.min.css"/>

    <script type="text/javascript" src="https://static-assets-ca.libguides.com/web/jquery/js/1.12.4_jquery.min.js"></script>

<!-- js_include_fallback_lg.twig -->
<script src="//code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script>jQuery.ui || document.write('<script src="https://static-assets-ca.libguides.com/web/jquery/js/jquery-ui.min.js?2691">\x3C/script>');</script>
<!-- !js_include_fallback_lg.twig -->

    <script type="text/javascript" src="https://static-assets-ca.libguides.com/web/js3.14.3/lg-public-no-bs.min.js"></script>

    <script src="https://static-assets-ca.libguides.com/web/select2-3.5.2/select2.js"></script>
    <link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/select2-3.5.2/select2.css"/>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

<!-- 
LibGuides Custom Bootstrap:
<link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/css3.14.3/lg-public.min.css">
-->
<style>
  /* BEGIN: Include dependencies from default LibGuide bundle */
  .hide {
    display: none;
  }
  #s-lg-az-index>.btn-group {
    flex-wrap: wrap;
  }
  
  .pagination {
      display: inline-block;
      padding-left: 0;
      margin: 20px 0;
      border-radius: 4px
  }

  .pagination>li {
      display: inline
  }

  .pagination>li>a,
  .pagination>li>span {
      position: relative;
      float: left;
      padding: 6px 12px;
      margin-left: -1px;
      line-height: 1.42857143;
      color: #337ab7;
      text-decoration: none;
      background-color: #fff;
      border: 1px solid #ddd
  }

  .pagination>li>a:hover,
  .pagination>li>span:hover,
  .pagination>li>a:focus,
  .pagination>li>span:focus {
      z-index: 2;
      color: #23527c;
      background-color: #eee;
      border-color: #ddd
  }

  .pagination>li:first-child>a,
  .pagination>li:first-child>span {
      margin-left: 0;
      border-top-left-radius: 4px;
      border-bottom-left-radius: 4px
  }

  .pagination>li:last-child>a,
  .pagination>li:last-child>span {
      border-top-right-radius: 4px;
      border-bottom-right-radius: 4px
  }

  .pagination>.active>a,
  .pagination>.active>span,
  .pagination>.active>a:hover,
  .pagination>.active>span:hover,
  .pagination>.active>a:focus,
  .pagination>.active>span:focus {
      z-index: 3;
      color: #fff;
      cursor: default;
      background-color: #337ab7;
      border-color: #337ab7
  }

  .pagination>.disabled>span,
  .pagination>.disabled>span:hover,
  .pagination>.disabled>span:focus,
  .pagination>.disabled>a,
  .pagination>.disabled>a:hover,
  .pagination>.disabled>a:focus {
      color: #777;
      cursor: not-allowed;
      background-color: #fff;
      border-color: #ddd
  }

  .pagination-lg>li>a,
  .pagination-lg>li>span {
      padding: 10px 16px;
      font-size: 18px;
      line-height: 1.3333333
  }

  .pagination-lg>li:first-child>a,
  .pagination-lg>li:first-child>span {
      border-top-left-radius: 6px;
      border-bottom-left-radius: 6px
  }

  .pagination-lg>li:last-child>a,
  .pagination-lg>li:last-child>span {
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px
  }

  .pagination-sm>li>a,
  .pagination-sm>li>span {
      padding: 5px 10px;
      font-size: 12px;
      line-height: 1.5
  }

  .pagination-sm>li:first-child>a,
  .pagination-sm>li:first-child>span {
      border-top-left-radius: 3px;
      border-bottom-left-radius: 3px
  }

  .pagination-sm>li:last-child>a,
  .pagination-sm>li:last-child>span {
      border-top-right-radius: 3px;
      border-bottom-right-radius: 3px
  }
  /* END: Include dependencies from default LibGuide bundle */

  select.form-control { /* Fix form select inputs */
    padding: .5rem .75rem 2rem .75rem
  }
  
  .navbar-collapse,
  body,
  .navbar-brand { /* Remove default LibGuides padding */
    padding: 0;
  }

  .navbar-brand {
    /* Place logo & text side by side */
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
  }

  .navbar-brand-logo {
    /* Scale Brand Logo */
    height: 3rem;
  }

  .navbar-brand-caption {
    /* Style Brand Text */
    text-wrap: wrap;
    font-size: .7rem;
    line-height: .7rem;
    font-weight: bold;
    text-transform: uppercase;
  }

  /* Hide default search bar */
  .pull-right>#s-lg-guide-header-search {
    display: none;
  }

  /* Any html inside an overhaul class is hidden by default. This lets us develop & test on the alternate guide without disturbing the development environment. */
  .overhaul {
    display: none !important;
  }

  /* CUSTOM TWEAKS*/
  /* Scale down profile image - Phillip's request */
  .s-lib-profile-image>img {
    width: 25%;
  }

  /* Remove tiny box title - Phillip's request */
  .s-lib-box-title {
    display: none;
  }

  /* Reformat google embeds to display properly. */
  .s-lg-widget>iframe {
    margin: auto !important;
    display: block !important;
  }
</style>
<script>
</script>

<script>
    var springStats = springStats || {};
    springStats.saConfig = springStats.saConfig || {
        site_id: 26075,
        tracking_parameters: {"_st_site_id":26075},
        tracking_server_host: "libguides-proc-ca.springyaws.com"
    };
</script>
<script  src="https://static-assets-ca.libguides.com/web/js/sa.min.js?3116"></script>


<script type="text/javascript">
    var title_base = "A-Z Databases";
    var search_data = {"terms":""};

    springSpace.publicObj = new springSpace.public.Public({
        constant: {
            PROCESSING: {},
            CONTENT: {}
        }
    });

    jQuery(document).ready(function () {
        if (window.history && history.pushState) {
            jQuery(window).bind("popstate", function (e) {
                // Don\'t reload list if this is the result of a skip link hash update.
                if (location.hash !== "#s-lib-public-main" && springSpace.azList.historyEdited) {
                    // location.search will return URL encoded values which will end up causing double-encoding when jQuery sends the loadAzList request.
                    var search_terms = decodeURIComponent(springSpace.Util.getQSParam({
                        name: "q",
                        qs: location.search
                    }));

                    springSpace.publicObj.loadAzList({
                        first: springSpace.Util.getQSParam({name: "a", qs: location.search}),
                        subject_id: springSpace.Util.getQSParam({name: "s", qs: location.search}),
                        type_id: springSpace.Util.getQSParam({name: "t", qs: location.search}),
                        vendor_id: springSpace.Util.getQSParam({name: "v", qs: location.search}),
                        access_mode_id: springSpace.Util.getQSParam({name: "am", qs: location.search}),
                        page: springSpace.Util.getQSParam({name: "p", qs: location.search}),
                        search: springSpace.Util.escapeHtml(search_terms),
                        site_id: 26075,
                        action: "back"
                    });
                }
            });
        }

        springSpace.azList.initSelections();

        // note that loadAzList is called with handle_alpha_filter=true so we can apply any passed in first-letter
        // filters after the search is complete
        if (springSpace.publicObj.getSearchTerm() == "") {
            springSpace.publicObj.loadAzList({
                first: "",
                subject_id: "",
                type_id: "",
                vendor_id: "",
                access_mode_id: "",
                page: 0,
                search: search_data.terms,
                site_id: 26075,
                action: "init"
            }, true);
        }
        // else, call filterAzBySearch so the passed in search string will be recorded
        else {
            springSpace.publicObj.filterAzBySearch(26075);
        }
    });

    springSpace.azList = {
        referrer: document.referrer,
        az_preview: "",
        locations: [],
        historyEdited: false,
        is_widget: 0,
        site_domain: "",
        init_filters: {
            subject: "",
            vendor: "",
            type: "",
            alpha: "",
            search: search_data.terms
        },
        letter_selected: "", // "first" alpha letter selecte so we can keep track.
        letter_alpha_map: {
            pound: "#",
            all: ""
        },
        getAlphaMap: function (letter) {
            if (letter == "pound" || letter == "all") {
                return this.letter_alpha_map[letter]
            } else {
                return letter;
            }
        },
        reset: function () {
            this.letter_selected = "";
            jQuery(".s-lg-az-first").removeClass("bold");
            jQuery(".s-lg-az-search").val("");
            springSpace.publicObj.clearAzSelection("s-lg-sel-az-types");
            springSpace.publicObj.clearAzSelection("s-lg-sel-subjects");
            springSpace.publicObj.clearAzSelection("s-lg-sel-az-vendors");
            springSpace.publicObj.clearAzSelection("s-lg-sel-az-access-modes");
            springSpace.publicObj.loadAzList({
                site_id: 26075
            });
        },
        initSelections: function () {
            // subject filter
            if (this.init_filters.subject == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-subjects");
            }

            // type filter
            if (this.init_filters.type == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-az-types");
            }

            // vendor filter
            if (this.init_filters.vendor == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-az-vendors");
            }

            // access modes filter
            if (this.init_filters.access_modes == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-az-access-modes");
            }

            // this.init_filters.alpha must be handled after the search results come back, so handling was moved inside
            // the loadAzList() call itself

            // search term
            if (this.init_filters.search == "") {
                jQuery(".s-lg-az-search").val("");
            } else {
                jQuery(".s-lg-az-search").val(this.init_filters.search);
            }
        }
    };

    
        jQuery(document).ready(function () {
            springSpace.springTrack.trackPage({_st_type_id: '17'});
        });
    
</script>




</head>
<body class="s-lib-public-body">
    <a id="s-lg-public-skiplink" class="alert-info" href="#s-lib-public-main">Skip to Main Content</a>
    <!-- BEGIN: Page Header -->
    <nav class="navbar navbar-expand-xl navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="/home">
            <img class="navbar-brand-logo"
                src="https://d1qywhc7l90rsa.cloudfront.net/accounts/165281/images/YHS-Rose-Lock-Up-Square-Full-Colour-RGB.png"
                alt="YHS Square Logo Lock-Up">
            <!-- Use CSS to wrap this text instead of hardcoded breaks if possible. -->
            <span class="navbar-brand-caption">Senior <br>Learning <br>Commons</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="/home">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Our Collection
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/az.php">All Resources</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/resources/catalogue" target="_blank">Our Catalogue</a></li>
                        <li><a class="dropdown-item" href="/orders">Request A Title</a></li>
                        <li><a class="dropdown-item" style="display: none;" href="#">Volunteer's Spotlight</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        How To..?
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/how-to">All "How To" Guides</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="/how-to/research-sources">Searching for Sources</a></li>
                        <li><a class="dropdown-item" href="/how-to/find-your-book">Find Your Next Book</a></li>
                        <li><a class="dropdown-item" href="/how-to/3d-printing">3D Printing</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        What Is..?
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/what-is">All "What Is" Guides</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/what-is/reading-lists">Reading Lists</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/what-is/truth-and-reconciliation">Truth & Reconcilliation</a></li>
                        <li><a class="dropdown-item" href="/what-is/mental-health">Mental Health</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Assignments
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/assignments">All Assignments</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/assignments/this-year">This Year</a></li>
                        <li><a class="dropdown-item" href="/assignments/2023-24">2023-24</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Student Initiatives
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/initiatives">All Initiatives</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/initiatives/publications">Student Publications</a></li>
                        <li><a class="dropdown-item" href="/initiatives/model-un">Model UN</a></li>
                        <li><a class="dropdown-item" style="display: none;" href="#">Tutoring</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/about">About</a>
                </li>
            </ul>
            <form class="d-flex" action="https://yorkhouse.libguides.com/srch.php" method="GET">
                <input class="form-control me-2" type="text" name="q" maxlength="260" placeholder="Search" aria-label="Search" role="search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>
    <!-- END: Page Header -->
    <!-- BEGIN: Content Header -->
    <div id="s-lib-public-header" class="s-lib-header container s-lib-side-borders">
        <nav id="s-lib-bc" aria-label="breadcrumb"><ol id="s-lib-bc-list" class="breadcrumb"><li id="s-lib-bc-customer" class="breadcrumb-item"><a href="https://www.yorkhouse.ca">York House School</a></li><li id="s-lib-bc-site" class="breadcrumb-item"><a href="https://yorkhouse.libguides.com/">LibGuides</a></li><li id="s-lib-bc-page" class="active breadcrumb-item">A-Z Databases</li></ol>
        </nav>
        <h1 id="s-lib-public-header-title">A-Z Databases</h1>
        <div id="s-lib-public-header-desc">Find the best library databases for your research.</div>
    </div>
    <!-- END: Content Header -->
    <!-- BEGIN: Nav Bar -->
    <div id="s-lib-public-nav" class="container s-lib-side-borders">
        
    </div>
    <!-- END: Nav Bar -->
    <!-- BEGIN: content -->
    <div id="s-lib-public-main" class="s-lib-main container s-lib-side-borders" tabindex="-1">
        <section>
            <div id="s-lg-az-search-bar" class="row">
                <div id="az-search-col-1" class="col-md-12 center">
                    
<nav class="navbar navbar-expand-lg navbar-default" aria-label="Search filters">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggler navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#s-lg-az-nav-1" data-bs-toggle="collapse" data-bs-target="#s-lg-az-nav-1">
                <span class="sr-only">Toggle search filters navigation</span>
                <span class="navbar-toggler-icon"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="s-lg-az-nav-1">
            <div id="s-lg-az-filters" style="padding-top:15px;">
                <section>
                    <div id="s-lg-az-filter-cols" class="row">
                                                                                    <div id="col-subjects" class="col-subjects col-md-3 center">
                                    <label class="control-label sr-only" for="s-lg-sel-subjects">Database Subject Filter</label><select id="s-lg-sel-subjects" name="s-lg-sel-subjects" class="s-lg-sel-subjects form-control" onChange="springSpace.publicObj.filterAzBySubject(jQuery(this).val(), 26075);"><option value="" selected>All Subjects</option><option value="138925">Deeper Analysis (1)</option><option value="138907">English (2)</option><option value="138905">Fiction (2)</option><option value="138924">Global News (3)</option><option value="138906">Multi-discipline (4)</option><option value="138908">Science (3)</option><option value="138909">Socials (5)</option></select>
                                </div>
                                                                                                                <div id="col-types" class="col-types col-md-3 center">
                                    <label class="control-label sr-only" for="s-lg-sel-az-types">Database Types Filter</label><select id="s-lg-sel-az-types" name="s-lg-sel-az-types" class="s-lg-sel-az-types form-control" onchange="springSpace.publicObj.filterAzByType(jQuery(this).val(), 26075);" data-placeholder="All Database Types"><option value="" selected>All Database Types</option><option value="28812">Digital (18)</option><option value="28809">Fiction (2)</option><option value="28807">Full text (19)</option><option value="28808">News articles (3)</option><option value="28810">Non-Fiction (18)</option><option value="28811">Physical (1)</option></select>
                                </div>
                                                                                                                <div id="col-vendors" class="col-vendors col-md-3 center">
                                    <label class="control-label sr-only" for="s-lg-sel-az-vendors">Database Vendors Filter</label><select id="s-lg-sel-az-vendors" name="s-lg-sel-az-vendors" class="s-lg-sel-az-vendors form-control" onchange="springSpace.publicObj.filterAzByVendor(jQuery(this).val(), 26075);" data-placeholder="All Vendors / Providers"><option value="" selected>All Vendors / Providers</option><option value="74453">Bloom (1)</option><option value="74450">Britannica (1)</option><option value="74444">Financial Times (1)</option><option value="74447">Follett (1)</option><option value="74449">Gale (4)</option><option value="74455">Infobase (4)</option><option value="74451">Jstor (1)</option><option value="74457">National Film Board (1)</option><option value="74446">New York Times (1)</option><option value="74445">Press Reader (1)</option><option value="74456">Science (1)</option><option value="74448">Sora (1)</option><option value="74454">YHS (1)</option></select>
                                </div>
                                                                                                                <div id="col-search" class="col-md-3 center">
                                    <form role="search"
                                          onsubmit="springSpace.publicObj.filterAzBySearch(26075); return false;">
                                        <div class="form-group">
                                            <label class="control-label sr-only" for="s-lg-az-search">
                                                DATABASES
                                            </label>

                                            <div class="input-group">
                                                <input type="text" class="s-lg-az-search form-control"
                                                       aria-label="Search for Databases"
                                                       placeholder="Search for Databases"
                                                       maxlength="260"/>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default btn-outline-secondary" type="submit"
                                                            aria-label="Go">
                                                        Go
                                                    </button>
                                                </span>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                                                        </div>
                </section>
            </div>
        </div>
    </div>
</nav>

                </div>
            </div>
        </section>
        <section>
            <div id="s-lg-az-cols" class="row">
                <div id="col1" class="col-md-8 center">
                    <div id="s-lg-az-search-reset" class="pad-right-sm">
                        <h2 id="s-lg-az-result-count" aria-live="polite" class="bold s-lib-text-lg pad-right-med"></h2> <button id="s-lg-az-reset" class="btn btn-default btn-sm s-lib-hide" type="button" onclick="springSpace.azList.reset();">Clear Filters/Browse All Databases</button>
                    </div>
                    <div id="s-lg-az-index" class="pad-right-sm">
                        <div class="btn-group" role="group" aria-label="Alpha-list to filter by first letter of database name"><button type="button" class="s-lg-az-header s-lg-az-first btn btn-link bold" id="s-lg-az-first-all" onclick="springSpace.publicObj.quickFilterAzByFirst('', 26075, 'All');">All</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-a" aria-label="Filter Results A" onclick="springSpace.publicObj.quickFilterAzByFirst('a', 26075);">A</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-b" aria-label="Filter Results B" onclick="springSpace.publicObj.quickFilterAzByFirst('b', 26075);">B</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">C</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">D</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">E</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-f" aria-label="Filter Results F" onclick="springSpace.publicObj.quickFilterAzByFirst('f', 26075);">F</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-g" aria-label="Filter Results G" onclick="springSpace.publicObj.quickFilterAzByFirst('g', 26075);">G</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-h" aria-label="Filter Results H" onclick="springSpace.publicObj.quickFilterAzByFirst('h', 26075);">H</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-i" aria-label="Filter Results I" onclick="springSpace.publicObj.quickFilterAzByFirst('i', 26075);">I</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-j" aria-label="Filter Results J" onclick="springSpace.publicObj.quickFilterAzByFirst('j', 26075);">J</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">K</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">L</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">M</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-n" aria-label="Filter Results N" onclick="springSpace.publicObj.quickFilterAzByFirst('n', 26075);">N</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">O</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-p" aria-label="Filter Results P" onclick="springSpace.publicObj.quickFilterAzByFirst('p', 26075);">P</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">Q</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">R</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-s" aria-label="Filter Results S" onclick="springSpace.publicObj.quickFilterAzByFirst('s', 26075);">S</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">T</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">U</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">V</button><button type="button" class="s-lg-az-header btn btn-link s-lg-az-first" id="s-lg-az-first-w" aria-label="Filter Results W" onclick="springSpace.publicObj.quickFilterAzByFirst('w', 26075);">W</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">X</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">Y</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">Z</button><button type="button" class="s-lg-disabled-text-contrast btn btn-link" disabled="disabled">#</button></div>
                    </div>
                    <div id="s-lg-az-content" class="pad-right-sm">
                        <div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div>
                    </div>
                </div>
                <div id="col2" class="col-md-4 center">
                    
                    <div id="s-lg-az-popular-div"><div class="margin-bottom-xlg"><div class="s-lib-public-side-header"><h2 class="pad-bottom-sm">Featured Databases</h2></div><div class="txt pad-top-sm"><div id="s-lg-az-popular-loading" class="bold s-lib-color-lt-grey pad-top-med">Loading...</div><div id="s-lg-az-popular">The most frequently-used databases


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/financial-times"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37423315&#039;,_st_inc_return: this});">
        Financial Times
            </a>
    <i class="fa fa-fw fa-external-link " 
            aria-label="This link opens in a new window" title="This link opens in a new window"
    ></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37423315,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description">Top-rated for international news.</div>
        
    
 
    
         
     
</div>


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/new-york-times"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37423329&#039;,_st_inc_return: this});">
        New York Times
            </a>
    <i class="fa fa-fw fa-external-link " 
            aria-label="This link opens in a new window" title="This link opens in a new window"
    ></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37423329,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description">Your first visit to this database must be on-campus, to register your device. After that you can also access FT off-campus.</div>
        
    
 
    
         
     
</div>


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/press-reader"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37423316&#039;,_st_inc_return: this});">
        Press Reader
            </a>
    <i class="fa fa-fw fa-external-link " 
            aria-label="This link opens in a new window" title="This link opens in a new window"
    ></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37423316,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description">7,000 newspapers & magazines from around the world.</div>
        
    
 
    
         
     
</div></div></div></div></div>
                    <div id="s-lg-az-trials-div"><div class="margin-bottom-xlg"><div class="s-lib-public-side-header"><h2 class="pad-bottom-sm">New / Trial Databases</h2></div><div class="txt pad-top-sm"><div id="s-lg-az-trials-loading" class="bold s-lib-color-lt-grey pad-top-med">Loading...</div><div id="s-lg-az-trials"><div id="s-lg-az-trials-none" class="s-lg-disabled-text-contrast">We are not evaluating any trial resources at this time.</div></div></div></div></div>
                    <div id="s-lg-az-experts-div"><div class="bold s-lib-color-lt-grey pad-top-med">Loading...</div></div>
                    <div id="s-lg-az-guides-div"><div class="bold s-lib-color-lt-grey pad-top-med">Loading...</div></div>
                </div>
            </div>
        </section>
    </div>
    <!-- END: content -->
    <!-- BEGIN: Page Footer -->
    <div id="s-lib-footer-public" class="container s-lib-footer footer s-lib-side-borders">
    <div>
        <div id="s-lib-footer-brand">
            Powered by Springshare.
        </div>
        <div id="s-lib-footer-rights">
            All rights reserved.
        </div>
        <div id="s-lib-footer-login-link">
            <a href="https://yorkhouse.libapps.com/libapps/login.php?site_id=26075">Login to LibApps</a>
        </div>
    </div>
    <div>
        <div id="s-lib-footer-support-link">
            
        </div>
    </div>
</div>
    <!-- END: Page Footer -->
    <div id="s-lib-alert" title="">
        <div id="s-lib-alert-content"></div>
    </div><!-- popover.twig -->
    <div id="s-lib-popover-title" class="hide">
        <span class="text-info">
            <strong>title</strong>
        </span>

        <button type="button" id="popclose" class="close" onclick="jQuery('.s-lib-popover').popover('hide')">
            &times;
        </button>
    </div>

    <div id="s-lib-popover-content" class="hide">
        <i class="fa fa-refresh fa-spin"></i> Loading...
        <button class="btn btn-default btn-sm popclose" type="button">Close</button>
    </div>
    <!-- !popover.twig -->
    <!-- scroll_top.twig -->
    <div id="s-lib-scroll-top">
        <a href="javascript:void(0);" onclick="jQuery('body').focus();" title="Back to Top" aria-label="Back to Top">
            <span class="fa-stack fa-lg" aria-hidden="true">
                <i class="fa fa-square-o fa-stack-2x"></i>
                <i class="fa fa-angle-double-up fa-stack-1x" style="position:relative; bottom:2px;"></i>
            </span>
        </a>
    </div>
    <!-- !scroll_top.twig -->

    <!-- BEGIN: Custom Footer -->
    
    <!-- END: Custom Footer -->
    <script>
        // Remove bootstrap navbar styling from generated filter element
        jQuery('#az-search-col-1 nav:first').removeClass();
        jQuery('#s-lg-az-nav-1').removeClass(); 
    </script>
</body>
</html>
